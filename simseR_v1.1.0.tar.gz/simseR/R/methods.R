#' Print method for simseR objects
#'
#' @param x An object of class "simseR"
#' @param ... Additional arguments (not used)
#'
#' @export
print.simseR <- function(x, ...) {
  cat("simseR: Automated Statistical Testing Results\n")
  cat("==========================================\n\n")
  
  # Normality test results
  cat("Normality Assessment (Shapiro-Wilk Test):\n")
  cat("------------------------------------------\n")
  cat("Group X: W =", round(x$normality_x$statistic, 4), 
      ", p-value =", round(x$normality_x$p.value, 4))
  if (x$normality_x$p.value > x$parameters$alpha) {
    cat(" (Normal)\n")
  } else {
    cat(" (Non-normal)\n")
  }
  
  if (!is.null(x$normality_y)) {
    cat("Group Y: W =", round(x$normality_y$statistic, 4), 
        ", p-value =", round(x$normality_y$p.value, 4))
    if (x$normality_y$p.value > x$parameters$alpha) {
      cat(" (Normal)\n")
    } else {
      cat(" (Non-normal)\n")
    }
  }
  
  cat("\nStatistical Test Performed:\n")
  cat("---------------------------\n")
  cat("Test:", x$test_used, "\n")
  
  # Test statistics
  if ("statistic" %in% names(x$test_result)) {
    stat_name <- names(x$test_result$statistic)
    cat("Test statistic:", stat_name, "=", round(x$test_result$statistic, 4), "\n")
  }
  
  cat("p-value:", round(x$test_result$p.value, 4), "\n")
  
  if ("conf.int" %in% names(x$test_result)) {
    ci_level <- attr(x$test_result$conf.int, "conf.level") * 100
    cat(ci_level, "% Confidence Interval: [", 
        round(x$test_result$conf.int[1], 4), ", ", 
        round(x$test_result$conf.int[2], 4), "]\n", sep = "")
  }
  
  cat("\nRecommendation:\n")
  cat("---------------\n")
  cat(x$recommendation, "\n")
}

#' Summary method for simseR objects
#'
#' @param object An object of class "simseR"
#' @param ... Additional arguments (not used)
#'
#' @export
summary.simseR <- function(object, ...) {
  cat("simseR Summary\n")
  cat("============\n\n")
  
  # Data summary
  cat("Data Summary:\n")
  cat("-------------\n")
  cat("Group X: n =", length(object$data_x), 
      ", mean =", round(mean(object$data_x), 4),
      ", sd =", round(sd(object$data_x), 4), "\n")
  
  if (!is.null(object$data_y)) {
    cat("Group Y: n =", length(object$data_y), 
        ", mean =", round(mean(object$data_y), 4),
        ", sd =", round(sd(object$data_y), 4), "\n")
  }
  
  # Call print method for detailed results
  cat("\n")
  print(object)
}

#' Extract test results in a clean format
#'
#' @param simseR_result An object of class "simseR"
#'
#' @return A data frame with key test results
#' @export
extract_results <- function(simseR_result) {
  if (!inherits(simseR_result, "simseR")) {
    stop("Input must be an object of class 'simseR'")
  }
  
  # Extract key information
  result_df <- data.frame(
    Test = simseR_result$test_used,
    Statistic = round(simseR_result$test_result$statistic, 4),
    P_value = round(simseR_result$test_result$p.value, 4),
    Significant = simseR_result$test_result$p.value < simseR_result$parameters$alpha,
    Normal_X = simseR_result$normality_x$p.value > simseR_result$parameters$alpha,
    stringsAsFactors = FALSE
  )
  
  if (!is.null(simseR_result$normality_y)) {
    result_df$Normal_Y <- simseR_result$normality_y$p.value > simseR_result$parameters$alpha
  }
  
  if ("conf.int" %in% names(simseR_result$test_result)) {
    result_df$CI_Lower <- round(simseR_result$test_result$conf.int[1], 4)
    result_df$CI_Upper <- round(simseR_result$test_result$conf.int[2], 4)
  }
  
  return(result_df)
}

