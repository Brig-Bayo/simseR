#' Create normality assessment plots using base R graphics
#'
#' This function creates comprehensive plots to assess normality of the data,
#' using only base R graphics functions to avoid external dependencies.
#'
#' @param simseR_result An object of class "simseR" from simseR_test()
#' @param main_title Main title for the plot (default: "Normality Assessment")
#' @param save_plot Logical, whether to save plot to file (default: FALSE)
#' @param filename Filename for saved plot (default: "normality_plots.png")
#'
#' @return Invisibly returns the simseR_result object
#' @export
plot_normality <- function(simseR_result, main_title = "Normality Assessment", 
                          save_plot = FALSE, filename = "normality_plots.png") {
  
  if (!inherits(simseR_result, "simseR")) {
    stop("Input must be an object of class 'simseR'")
  }
  
  # Extract data
  x <- simseR_result$data_x
  y <- simseR_result$data_y
  
  # Set up plotting device
  if (save_plot) {
    png(filename, width = 1200, height = 800, res = 100)
  }
  
  # Determine layout based on number of groups
  if (!is.null(y)) {
    # Two groups: 2 rows, 3 columns
    par(mfrow = c(2, 3), mar = c(4, 4, 3, 2), oma = c(0, 0, 3, 0))
  } else {
    # One group: 1 row, 3 columns
    par(mfrow = c(1, 3), mar = c(4, 4, 3, 2), oma = c(0, 0, 3, 0))
  }
  
  # Create plots for group X
  create_normality_plots_base(x, "Group X", simseR_result$normality_x)
  
  if (!is.null(y)) {
    # Create plots for group Y
    create_normality_plots_base(y, "Group Y", simseR_result$normality_y)
  }
  
  # Add main title
  mtext(main_title, outer = TRUE, cex = 1.5, font = 2)
  
  if (save_plot) {
    dev.off()
    cat("Normality plots saved to:", filename, "\n")
  }
  
  # Reset plotting parameters
  par(mfrow = c(1, 1), mar = c(5, 4, 4, 2), oma = c(0, 0, 0, 0))
  
  invisible(simseR_result)
}

#' Create individual normality plots for a dataset using base R
#'
#' @param data Numeric vector of data
#' @param group_name Name of the group for labeling
#' @param shapiro_result Results from shapiro.test()
#'
#' @keywords internal
create_normality_plots_base <- function(data, group_name, shapiro_result) {
  
  # 1. Histogram with normal overlay
  hist(data, 
       main = paste("Histogram -", group_name),
       xlab = "Value", 
       ylab = "Density",
       col = "lightblue", 
       border = "black",
       freq = FALSE,
       breaks = min(15, length(data)/2))
  
  # Add normal distribution overlay
  x_seq <- seq(min(data), max(data), length.out = 100)
  normal_curve <- dnorm(x_seq, mean = mean(data), sd = sd(data))
  lines(x_seq, normal_curve, col = "red", lwd = 2)
  
  # Add legend
  legend("topright", legend = "Normal curve", col = "red", lwd = 2, cex = 0.8)
  
  # 2. Q-Q plot
  qqnorm(data, 
         main = paste("Q-Q Plot -", group_name),
         xlab = "Theoretical Quantiles",
         ylab = "Sample Quantiles",
         pch = 16, 
         col = "blue")
  qqline(data, col = "red", lwd = 2)
  
  # 3. Boxplot with Shapiro-Wilk p-value
  boxplot(data, 
          main = paste("Boxplot -", group_name),
          ylab = "Value",
          col = "lightgreen",
          border = "black")
  
  # Add Shapiro-Wilk p-value as text
  text(x = 1, y = max(data), 
       labels = paste("Shapiro-Wilk p =", round(shapiro_result$p.value, 4)),
       pos = 3, cex = 0.9, font = 2)
}

#' Create results visualization plots using base R graphics
#'
#' This function creates plots to visualize the test results and data comparison.
#'
#' @param simseR_result An object of class "simseR" from simseR_test()
#' @param main_title Main title for the plot (default: "Test Results")
#' @param save_plot Logical, whether to save plot to file (default: FALSE)
#' @param filename Filename for saved plot (default: "results_plots.png")
#'
#' @return Invisibly returns the simseR_result object
#' @export
plot_results <- function(simseR_result, main_title = "Test Results",
                        save_plot = FALSE, filename = "results_plots.png") {
  
  if (!inherits(simseR_result, "simseR")) {
    stop("Input must be an object of class 'simseR'")
  }
  
  x <- simseR_result$data_x
  y <- simseR_result$data_y
  
  # Set up plotting device
  if (save_plot) {
    png(filename, width = 1000, height = 600, res = 100)
  }
  
  if (is.null(y)) {
    # One-sample test visualization
    par(mfrow = c(1, 2), mar = c(4, 4, 3, 2), oma = c(0, 0, 3, 0))
    create_one_sample_plots_base(x, simseR_result)
  } else {
    # Two-sample test visualization
    par(mfrow = c(1, 3), mar = c(4, 4, 3, 2), oma = c(0, 0, 3, 0))
    create_two_sample_plots_base(x, y, simseR_result)
  }
  
  # Add main title
  mtext(main_title, outer = TRUE, cex = 1.5, font = 2)
  
  if (save_plot) {
    dev.off()
    cat("Results plots saved to:", filename, "\n")
  }
  
  # Reset plotting parameters
  par(mfrow = c(1, 1), mar = c(5, 4, 4, 2), oma = c(0, 0, 0, 0))
  
  invisible(simseR_result)
}

#' Create plots for one-sample test results using base R
#'
#' @param data Numeric vector of data
#' @param simseR_result simseR test results
#'
#' @keywords internal
create_one_sample_plots_base <- function(data, simseR_result) {
  
  mu <- simseR_result$parameters$mu
  
  # 1. Data distribution with reference lines
  hist(data, 
       main = "Data Distribution",
       xlab = "Value", 
       ylab = "Frequency",
       col = "lightblue", 
       border = "black",
       breaks = min(15, length(data)/2))
  
  # Add reference lines
  abline(v = mu, col = "red", lty = 2, lwd = 2)
  abline(v = mean(data), col = "blue", lwd = 2)
  
  # Add legend
  legend("topright", 
         legend = c(paste("μ₀ =", mu), paste("Sample mean =", round(mean(data), 3))),
         col = c("red", "blue"), 
         lty = c(2, 1), 
         lwd = 2, 
         cex = 0.8)
  
  # 2. Test summary plot
  create_test_summary_plot_base(simseR_result)
}

#' Create plots for two-sample test results using base R
#'
#' @param x First group data
#' @param y Second group data
#' @param simseR_result simseR test results
#'
#' @keywords internal
create_two_sample_plots_base <- function(x, y, simseR_result) {
  
  # 1. Side-by-side boxplots
  boxplot(list("Group X" = x, "Group Y" = y),
          main = "Group Comparison",
          ylab = "Value",
          col = c("lightblue", "lightgreen"),
          border = "black")
  
  # Add points for individual observations
  stripchart(list("Group X" = x, "Group Y" = y), 
             vertical = TRUE, 
             method = "jitter", 
             add = TRUE, 
             pch = 16, 
             col = c("darkblue", "darkgreen"),
             cex = 0.6)
  
  # 2. Density comparison
  plot(density(x), 
       main = "Density Comparison",
       xlab = "Value", 
       ylab = "Density",
       col = "blue", 
       lwd = 2,
       xlim = range(c(x, y)))
  
  lines(density(y), col = "green", lwd = 2)
  
  # Add legend
  legend("topright", 
         legend = c("Group X", "Group Y"), 
         col = c("blue", "green"), 
         lwd = 2, 
         cex = 0.8)
  
  # 3. Test summary
  create_test_summary_plot_base(simseR_result)
}

#' Create test summary visualization using base R
#'
#' @param simseR_result simseR test results
#'
#' @keywords internal
create_test_summary_plot_base <- function(simseR_result) {
  
  # Create a text-based summary plot
  plot(0, 0, type = "n", xlim = c(0, 1), ylim = c(0, 1), 
       xlab = "", ylab = "", main = "Test Summary",
       axes = FALSE)
  
  # Add summary text
  summary_lines <- c(
    paste("Test:", simseR_result$test_used),
    paste("P-value:", round(simseR_result$test_result$p.value, 4)),
    paste("Significant:", ifelse(simseR_result$test_result$p.value < simseR_result$parameters$alpha, "Yes", "No")),
    paste("Normal data:", ifelse(simseR_result$is_normal, "Yes", "No"))
  )
  
  # Position text in center
  y_positions <- seq(0.7, 0.3, length.out = length(summary_lines))
  
  for (i in seq_along(summary_lines)) {
    text(0.5, y_positions[i], summary_lines[i], 
         cex = 1.1, font = 2, adj = 0.5)
  }
  
  # Add border
  box()
}

#' Plot method for simseR objects using base R graphics
#'
#' @param x An object of class "simseR"
#' @param type Type of plot: "normality", "results", or "both" (default: "both")
#' @param save_plots Logical, whether to save plots to files (default: FALSE)
#' @param ... Additional arguments (not used)
#'
#' @export
plot.simseR <- function(x, type = "both", save_plots = FALSE, ...) {
  
  if (type == "normality") {
    plot_normality(x, save_plot = save_plots, filename = "simseR_normality.png")
  } else if (type == "results") {
    plot_results(x, save_plot = save_plots, filename = "simseR_results.png")
  } else if (type == "both") {
    # Create both types of plots
    plot_normality(x, main_title = "Normality Assessment", 
                   save_plot = save_plots, filename = "simseR_normality.png")
    
    # Add a pause for interactive sessions
    if (interactive() && !save_plots) {
      readline(prompt = "Press [enter] to see test results plots...")
    }
    
    plot_results(x, main_title = "Test Results",
                 save_plot = save_plots, filename = "simseR_results.png")
  } else {
    stop("type must be 'normality', 'results', or 'both'")
  }
  
  invisible(x)
}

#' Create a comprehensive plot combining normality and results
#'
#' @param simseR_result An object of class "simseR" from simseR_test()
#' @param save_plot Logical, whether to save plot to file (default: FALSE)
#' @param filename Filename for saved plot (default: "simseR_comprehensive.png")
#'
#' @return Invisibly returns the simseR_result object
#' @export
plot_comprehensive <- function(simseR_result, save_plot = FALSE, 
                              filename = "simseR_comprehensive.png") {
  
  if (!inherits(simseR_result, "simseR")) {
    stop("Input must be an object of class 'simseR'")
  }
  
  x <- simseR_result$data_x
  y <- simseR_result$data_y
  
  # Set up plotting device
  if (save_plot) {
    png(filename, width = 1400, height = 1000, res = 100)
  }
  
  if (is.null(y)) {
    # One-sample: 2x3 layout
    par(mfrow = c(2, 3), mar = c(4, 4, 3, 2), oma = c(0, 0, 3, 0))
    
    # Normality plots
    create_normality_plots_base(x, "Group X", simseR_result$normality_x)
    
    # Results plots
    create_one_sample_plots_base(x, simseR_result)
    
    # Add empty plot for symmetry
    plot.new()
    
  } else {
    # Two-sample: 3x3 layout
    par(mfrow = c(3, 3), mar = c(4, 4, 3, 2), oma = c(0, 0, 3, 0))
    
    # Normality plots for both groups
    create_normality_plots_base(x, "Group X", simseR_result$normality_x)
    create_normality_plots_base(y, "Group Y", simseR_result$normality_y)
    
    # Results plots
    create_two_sample_plots_base(x, y, simseR_result)
  }
  
  # Add main title
  mtext("simseR: Comprehensive Statistical Analysis", outer = TRUE, cex = 1.8, font = 2)
  
  if (save_plot) {
    dev.off()
    cat("Comprehensive plot saved to:", filename, "\n")
  }
  
  # Reset plotting parameters
  par(mfrow = c(1, 1), mar = c(5, 4, 4, 2), oma = c(0, 0, 0, 0))
  
  invisible(simseR_result)
}

#' Create a simple diagnostic plot for quick assessment
#'
#' @param simseR_result An object of class "simseR" from simseR_test()
#' @param save_plot Logical, whether to save plot to file (default: FALSE)
#' @param filename Filename for saved plot (default: "simseR_diagnostic.png")
#'
#' @return Invisibly returns the simseR_result object
#' @export
plot_diagnostic <- function(simseR_result, save_plot = FALSE, 
                           filename = "simseR_diagnostic.png") {
  
  if (!inherits(simseR_result, "simseR")) {
    stop("Input must be an object of class 'simseR'")
  }
  
  x <- simseR_result$data_x
  y <- simseR_result$data_y
  
  # Set up plotting device
  if (save_plot) {
    png(filename, width = 800, height = 600, res = 100)
  }
  
  if (is.null(y)) {
    # One-sample diagnostic
    par(mfrow = c(2, 2), mar = c(4, 4, 3, 2), oma = c(0, 0, 3, 0))
    
    # Histogram
    hist(x, main = "Data Distribution", col = "lightblue", xlab = "Value")
    
    # Q-Q plot
    qqnorm(x, main = "Normality Check")
    qqline(x, col = "red")
    
    # Boxplot
    boxplot(x, main = "Outlier Detection", col = "lightgreen")
    
    # Summary text
    create_test_summary_plot_base(simseR_result)
    
  } else {
    # Two-sample diagnostic
    par(mfrow = c(2, 2), mar = c(4, 4, 3, 2), oma = c(0, 0, 3, 0))
    
    # Group comparison
    boxplot(list("Group X" = x, "Group Y" = y), 
            main = "Group Comparison", 
            col = c("lightblue", "lightgreen"))
    
    # Combined Q-Q plot
    qqnorm(c(x, y), main = "Combined Normality Check")
    qqline(c(x, y), col = "red")
    
    # Density comparison
    plot(density(x), main = "Density Comparison", col = "blue", lwd = 2)
    lines(density(y), col = "green", lwd = 2)
    legend("topright", c("Group X", "Group Y"), col = c("blue", "green"), lwd = 2)
    
    # Summary text
    create_test_summary_plot_base(simseR_result)
  }
  
  # Add main title
  mtext("simseR: Diagnostic Plots", outer = TRUE, cex = 1.5, font = 2)
  
  if (save_plot) {
    dev.off()
    cat("Diagnostic plot saved to:", filename, "\n")
  }
  
  # Reset plotting parameters
  par(mfrow = c(1, 1), mar = c(5, 4, 4, 2), oma = c(0, 0, 0, 0))
  
  invisible(simseR_result)
}

