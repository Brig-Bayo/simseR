#' Generate Report for simseR Analysis (Base R Version)
#'
#' This function creates a comprehensive report using base R functionality,
#' avoiding dependencies on external packages like rmarkdown or knitr.
#'
#' @param simseR_result An object of class "simseR" from simseR_test()
#' @param output_file Path for the output file (supports .txt, .html, .md)
#' @param title Title for the report (default: "Statistical Analysis Report")
#' @param author Author name for the report (default: "simseR Package")
#' @param include_data Logical, whether to include raw data in the report (default: FALSE)
#' @param format Output format: "html", "text", or "markdown" (default: "html")
#'
#' @return Path to the generated report file
#' @export
simseR_report <- function(simseR_result, output_file = "simseR_report.html", 
                        title = "Statistical Analysis Report", 
                        author = "simseR Package", include_data = FALSE,
                        format = "html") {
  
  if (!inherits(simseR_result, "simseR")) {
    stop("Input must be an object of class 'simseR'")
  }
  
  # Determine format from file extension if not specified
  if (missing(format)) {
    ext <- tools::file_ext(output_file)
    format <- switch(tolower(ext),
                     "html" = "html",
                     "htm" = "html", 
                     "txt" = "text",
                     "md" = "markdown",
                     "html") # default to html
  }
  
  # Generate report content based on format
  if (format == "html") {
    content <- generate_html_report(simseR_result, title, author, include_data)
  } else if (format == "text") {
    content <- generate_text_report(simseR_result, title, author, include_data)
  } else if (format == "markdown") {
    content <- generate_markdown_report(simseR_result, title, author, include_data)
  } else {
    stop("Unsupported format. Use 'html', 'text', or 'markdown'")
  }
  
  # Write content to file
  tryCatch({
    writeLines(content, output_file, useBytes = TRUE)
    cat("Report generated successfully:", output_file, "\n")
    return(output_file)
  }, error = function(e) {
    stop("Failed to write report file: ", e$message)
  })
}

#' Generate HTML report content
#'
#' @param simseR_result simseR test results
#' @param title Report title
#' @param author Report author
#' @param include_data Whether to include raw data
#'
#' @return Character vector with HTML content
#' @keywords internal
generate_html_report <- function(simseR_result, title, author, include_data) {
  
  # Extract key information
  x <- simseR_result$data_x
  y <- simseR_result$data_y
  is_two_sample <- !is.null(y)
  
  # Start building HTML content
  html_content <- c(
    "<!DOCTYPE html>",
    "<html lang='en'>",
    "<head>",
    "    <meta charset='UTF-8'>",
    "    <meta name='viewport' content='width=device-width, initial-scale=1.0'>",
    paste0("    <title>", title, "</title>"),
    "    <style>",
    "        body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }",
    "        h1 { color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 10px; }",
    "        h2 { color: #34495e; border-bottom: 1px solid #bdc3c7; padding-bottom: 5px; }",
    "        h3 { color: #7f8c8d; }",
    "        .summary-box { background-color: #ecf0f1; padding: 15px; border-radius: 5px; margin: 20px 0; }",
    "        .result-table { border-collapse: collapse; width: 100%; margin: 20px 0; }",
    "        .result-table th, .result-table td { border: 1px solid #bdc3c7; padding: 8px; text-align: left; }",
    "        .result-table th { background-color: #3498db; color: white; }",
    "        .significant { color: #e74c3c; font-weight: bold; }",
    "        .not-significant { color: #27ae60; font-weight: bold; }",
    "        .normal { color: #27ae60; }",
    "        .non-normal { color: #e74c3c; }",
    "        .code { background-color: #f8f9fa; padding: 10px; border-radius: 3px; font-family: monospace; }",
    "        .recommendation { background-color: #d5f4e6; padding: 15px; border-radius: 5px; border-left: 4px solid #27ae60; }",
    "    </style>",
    "</head>",
    "<body>",
    paste0("    <h1>", title, "</h1>"),
    paste0("    <p><strong>Author:</strong> ", author, "</p>"),
    paste0("    <p><strong>Generated:</strong> ", Sys.time(), "</p>"),
    "",
    "    <div class='summary-box'>",
    "        <h2>Executive Summary</h2>",
    paste0("        <p><strong>Test Performed:</strong> ", simseR_result$test_used, "</p>"),
    paste0("        <p><strong>P-value:</strong> ", round(simseR_result$test_result$p.value, 4), "</p>"),
    paste0("        <p><strong>Significant:</strong> <span class='", 
           ifelse(simseR_result$test_result$p.value < simseR_result$parameters$alpha, "significant'>Yes", "not-significant'>No"), 
           "</span></p>"),
    paste0("        <p><strong>Normality Assumption Met:</strong> <span class='", 
           ifelse(simseR_result$is_normal, "normal'>Yes", "non-normal'>No"), 
           "</span></p>"),
    "    </div>",
    "",
    generate_html_data_section(x, y),
    "",
    generate_html_normality_section(simseR_result),
    "",
    generate_html_test_results_section(simseR_result),
    "",
    generate_html_recommendation_section(simseR_result),
    "",
    generate_html_technical_section(simseR_result)
  )
  
  # Add raw data section if requested
  if (include_data) {
    html_content <- c(html_content, "", generate_html_data_tables(x, y))
  }
  
  # Close HTML
  html_content <- c(html_content, "", "</body>", "</html>")
  
  return(html_content)
}

#' Generate text report content
#'
#' @param simseR_result simseR test results
#' @param title Report title
#' @param author Report author
#' @param include_data Whether to include raw data
#'
#' @return Character vector with text content
#' @keywords internal
generate_text_report <- function(simseR_result, title, author, include_data) {
  
  x <- simseR_result$data_x
  y <- simseR_result$data_y
  
  text_content <- c(
    paste(rep("=", nchar(title)), collapse = ""),
    title,
    paste(rep("=", nchar(title)), collapse = ""),
    "",
    paste("Author:", author),
    paste("Generated:", Sys.time()),
    "",
    "EXECUTIVE SUMMARY",
    "-----------------",
    paste("Test Performed:", simseR_result$test_used),
    paste("P-value:", round(simseR_result$test_result$p.value, 4)),
    paste("Significant:", ifelse(simseR_result$test_result$p.value < simseR_result$parameters$alpha, "Yes", "No")),
    paste("Normality Assumption Met:", ifelse(simseR_result$is_normal, "Yes", "No")),
    "",
    "DATA OVERVIEW",
    "-------------",
    generate_text_data_section(x, y),
    "",
    "NORMALITY ASSESSMENT",
    "-------------------",
    generate_text_normality_section(simseR_result),
    "",
    "STATISTICAL TEST RESULTS", 
    "-----------------------",
    generate_text_test_results_section(simseR_result),
    "",
    "RECOMMENDATION",
    "--------------",
    simseR_result$recommendation,
    "",
    "TECHNICAL DETAILS",
    "----------------",
    generate_text_technical_section(simseR_result)
  )
  
  if (include_data) {
    text_content <- c(text_content, "", "RAW DATA", "--------", generate_text_data_tables(x, y))
  }
  
  return(text_content)
}

#' Generate markdown report content
#'
#' @param simseR_result simseR test results
#' @param title Report title
#' @param author Report author
#' @param include_data Whether to include raw data
#'
#' @return Character vector with markdown content
#' @keywords internal
generate_markdown_report <- function(simseR_result, title, author, include_data) {
  
  x <- simseR_result$data_x
  y <- simseR_result$data_y
  
  md_content <- c(
    paste("#", title),
    "",
    paste("**Author:** ", author),
    paste("**Generated:** ", Sys.time()),
    "",
    "## Executive Summary",
    "",
    paste("- **Test Performed:** ", simseR_result$test_used),
    paste("- **P-value:** ", round(simseR_result$test_result$p.value, 4)),
    paste("- **Significant:** ", ifelse(simseR_result$test_result$p.value < simseR_result$parameters$alpha, "Yes", "No")),
    paste("- **Normality Assumption Met:** ", ifelse(simseR_result$is_normal, "Yes", "No")),
    "",
    "## Data Overview",
    "",
    generate_markdown_data_section(x, y),
    "",
    "## Normality Assessment",
    "",
    generate_markdown_normality_section(simseR_result),
    "",
    "## Statistical Test Results",
    "",
    generate_markdown_test_results_section(simseR_result),
    "",
    "## Recommendation",
    "",
    simseR_result$recommendation,
    "",
    "## Technical Details",
    "",
    generate_markdown_technical_section(simseR_result)
  )
  
  if (include_data) {
    md_content <- c(md_content, "", "## Raw Data", "", generate_markdown_data_tables(x, y))
  }
  
  return(md_content)
}

# Helper functions for HTML sections
generate_html_data_section <- function(x, y) {
  content <- c(
    "    <h2>Data Overview</h2>",
    "    <table class='result-table'>",
    "        <tr><th>Statistic</th><th>Group X</th>"
  )
  
  if (!is.null(y)) {
    content <- c(content, "<th>Group Y</th>")
  }
  content <- c(content, "</tr>")
  
  # Add statistics rows
  stats_rows <- c(
    paste0("        <tr><td>Sample Size</td><td>", length(x), "</td>"),
    paste0("        <tr><td>Mean</td><td>", round(mean(x), 4), "</td>"),
    paste0("        <tr><td>Standard Deviation</td><td>", round(sd(x), 4), "</td>"),
    paste0("        <tr><td>Median</td><td>", round(median(x), 4), "</td>"),
    paste0("        <tr><td>Range</td><td>[", round(min(x), 4), ", ", round(max(x), 4), "]</td>")
  )
  
  if (!is.null(y)) {
    stats_rows <- paste0(stats_rows, 
                        c(paste0("<td>", length(y), "</td></tr>"),
                          paste0("<td>", round(mean(y), 4), "</td></tr>"),
                          paste0("<td>", round(sd(y), 4), "</td></tr>"),
                          paste0("<td>", round(median(y), 4), "</td></tr>"),
                          paste0("<td>[", round(min(y), 4), ", ", round(max(y), 4), "]</td></tr>")))
  } else {
    stats_rows <- paste0(stats_rows, "</tr>")
  }
  
  content <- c(content, stats_rows, "    </table>")
  return(content)
}

generate_html_normality_section <- function(simseR_result) {
  content <- c(
    "    <h2>Normality Assessment</h2>",
    "    <p>The Shapiro-Wilk test was used to assess normality of the data.</p>",
    "    <table class='result-table'>",
    "        <tr><th>Group</th><th>W Statistic</th><th>P-value</th><th>Normal?</th></tr>",
    paste0("        <tr><td>Group X</td><td>", round(simseR_result$normality_x$statistic, 4), 
           "</td><td>", round(simseR_result$normality_x$p.value, 4), 
           "</td><td><span class='", ifelse(simseR_result$normality_x$p.value > simseR_result$parameters$alpha, "normal'>Yes", "non-normal'>No"), 
           "</span></td></tr>")
  )
  
  if (!is.null(simseR_result$normality_y)) {
    content <- c(content,
      paste0("        <tr><td>Group Y</td><td>", round(simseR_result$normality_y$statistic, 4), 
             "</td><td>", round(simseR_result$normality_y$p.value, 4), 
             "</td><td><span class='", ifelse(simseR_result$normality_y$p.value > simseR_result$parameters$alpha, "normal'>Yes", "non-normal'>No"), 
             "</span></td></tr>")
    )
  }
  
  content <- c(content, "    </table>")
  return(content)
}

generate_html_test_results_section <- function(simseR_result) {
  test_result <- simseR_result$test_result
  
  content <- c(
    "    <h2>Statistical Test Results</h2>",
    paste0("    <p><strong>Test Used:</strong> ", simseR_result$test_used, "</p>"),
    "    <table class='result-table'>",
    "        <tr><th>Statistic</th><th>Value</th></tr>",
    paste0("        <tr><td>Test Statistic</td><td>", round(test_result$statistic, 4), "</td></tr>"),
    paste0("        <tr><td>P-value</td><td>", round(test_result$p.value, 4), "</td></tr>"),
    paste0("        <tr><td>Significant (α = ", simseR_result$parameters$alpha, ")</td><td><span class='", 
           ifelse(test_result$p.value < simseR_result$parameters$alpha, "significant'>Yes", "not-significant'>No"), 
           "</span></td></tr>")
  )
  
  if ("conf.int" %in% names(test_result)) {
    ci_level <- attr(test_result$conf.int, "conf.level") * 100
    content <- c(content,
      paste0("        <tr><td>", ci_level, "% Confidence Interval</td><td>[", 
             round(test_result$conf.int[1], 4), ", ", 
             round(test_result$conf.int[2], 4), "]</td></tr>")
    )
  }
  
  content <- c(content, "    </table>")
  return(content)
}

generate_html_recommendation_section <- function(simseR_result) {
  c(
    "    <div class='recommendation'>",
    "        <h2>Recommendation</h2>",
    paste0("        <p>", simseR_result$recommendation, "</p>"),
    "    </div>"
  )
}

generate_html_technical_section <- function(simseR_result) {
  c(
    "    <h2>Technical Details</h2>",
    paste0("    <p><strong>R Version:</strong> ", R.version.string, "</p>"),
    paste0("    <p><strong>simseR Package Version:</strong> 1.0.0</p>"),
    paste0("    <p><strong>Analysis Date:</strong> ", Sys.Date(), "</p>"),
    "    <h3>Test Selection Logic</h3>",
    "    <p>The simseR package automatically selects appropriate statistical tests:</p>",
    "    <ol>",
    "        <li>Shapiro-Wilk test assesses normality for all groups</li>",
    "        <li>If all groups are normal (p > α): Use parametric tests (t-tests)</li>",
    "        <li>If any group is non-normal (p ≤ α): Use non-parametric tests (Wilcoxon)</li>",
    "    </ol>"
  )
}

# Helper functions for text sections
generate_text_data_section <- function(x, y) {
  content <- c(
    paste("Group X: n =", length(x), ", mean =", round(mean(x), 4), ", sd =", round(sd(x), 4))
  )
  
  if (!is.null(y)) {
    content <- c(content,
      paste("Group Y: n =", length(y), ", mean =", round(mean(y), 4), ", sd =", round(sd(y), 4))
    )
  }
  
  return(content)
}

generate_text_normality_section <- function(simseR_result) {
  content <- c(
    paste("Group X: W =", round(simseR_result$normality_x$statistic, 4), 
          ", p-value =", round(simseR_result$normality_x$p.value, 4),
          ifelse(simseR_result$normality_x$p.value > simseR_result$parameters$alpha, "(Normal)", "(Non-normal)"))
  )
  
  if (!is.null(simseR_result$normality_y)) {
    content <- c(content,
      paste("Group Y: W =", round(simseR_result$normality_y$statistic, 4), 
            ", p-value =", round(simseR_result$normality_y$p.value, 4),
            ifelse(simseR_result$normality_y$p.value > simseR_result$parameters$alpha, "(Normal)", "(Non-normal)"))
    )
  }
  
  return(content)
}

generate_text_test_results_section <- function(simseR_result) {
  test_result <- simseR_result$test_result
  
  content <- c(
    paste("Test:", simseR_result$test_used),
    paste("Test statistic:", round(test_result$statistic, 4)),
    paste("P-value:", round(test_result$p.value, 4)),
    paste("Significant:", ifelse(test_result$p.value < simseR_result$parameters$alpha, "Yes", "No"))
  )
  
  if ("conf.int" %in% names(test_result)) {
    ci_level <- attr(test_result$conf.int, "conf.level") * 100
    content <- c(content,
      paste(ci_level, "% Confidence Interval: [", 
            round(test_result$conf.int[1], 4), ", ", 
            round(test_result$conf.int[2], 4), "]")
    )
  }
  
  return(content)
}

generate_text_technical_section <- function(simseR_result) {
  c(
    paste("R Version:", R.version.string),
    paste("simseR Package Version: 1.0.0"),
    paste("Analysis Date:", Sys.Date()),
    "",
    "Test Selection Logic:",
    "1. Shapiro-Wilk test assesses normality",
    "2. Normal data → Parametric tests (t-tests)",
    "3. Non-normal data → Non-parametric tests (Wilcoxon)"
  )
}

# Similar helper functions for markdown (simplified versions)
generate_markdown_data_section <- function(x, y) {
  content <- c(
    "| Statistic | Group X |"
  )
  
  if (!is.null(y)) {
    content[1] <- paste(content[1], "Group Y |")
    content <- c(content, "|-----------|---------|---------|")
  } else {
    content <- c(content, "|-----------|---------|")
  }
  
  stats <- c(
    paste("| Sample Size |", length(x), "|"),
    paste("| Mean |", round(mean(x), 4), "|"),
    paste("| Standard Deviation |", round(sd(x), 4), "|"),
    paste("| Median |", round(median(x), 4), "|"),
    paste("| Range | [", round(min(x), 4), ", ", round(max(x), 4), "] |")
  )
  
  if (!is.null(y)) {
    stats <- c(
      paste("| Sample Size |", length(x), "|", length(y), "|"),
      paste("| Mean |", round(mean(x), 4), "|", round(mean(y), 4), "|"),
      paste("| Standard Deviation |", round(sd(x), 4), "|", round(sd(y), 4), "|"),
      paste("| Median |", round(median(x), 4), "|", round(median(y), 4), "|"),
      paste("| Range | [", round(min(x), 4), ", ", round(max(x), 4), "] | [", round(min(y), 4), ", ", round(max(y), 4), "] |")
    )
  }
  
  return(c(content, stats))
}

generate_markdown_normality_section <- function(simseR_result) {
  content <- c(
    "| Group | W Statistic | P-value | Normal? |",
    "|-------|-------------|---------|---------|",
    paste("| Group X |", round(simseR_result$normality_x$statistic, 4), "|", 
          round(simseR_result$normality_x$p.value, 4), "|", 
          ifelse(simseR_result$normality_x$p.value > simseR_result$parameters$alpha, "Yes", "No"), "|")
  )
  
  if (!is.null(simseR_result$normality_y)) {
    content <- c(content,
      paste("| Group Y |", round(simseR_result$normality_y$statistic, 4), "|", 
            round(simseR_result$normality_y$p.value, 4), "|", 
            ifelse(simseR_result$normality_y$p.value > simseR_result$parameters$alpha, "Yes", "No"), "|")
    )
  }
  
  return(content)
}

generate_markdown_test_results_section <- function(simseR_result) {
  test_result <- simseR_result$test_result
  
  content <- c(
    paste("**Test Used:** ", simseR_result$test_used),
    "",
    "| Statistic | Value |",
    "|-----------|-------|",
    paste("| Test Statistic |", round(test_result$statistic, 4), "|"),
    paste("| P-value |", round(test_result$p.value, 4), "|"),
    paste("| Significant |", ifelse(test_result$p.value < simseR_result$parameters$alpha, "Yes", "No"), "|")
  )
  
  if ("conf.int" %in% names(test_result)) {
    ci_level <- attr(test_result$conf.int, "conf.level") * 100
    content <- c(content,
      paste("|", ci_level, "% Confidence Interval | [", 
            round(test_result$conf.int[1], 4), ", ", 
            round(test_result$conf.int[2], 4), "] |")
    )
  }
  
  return(content)
}

generate_markdown_technical_section <- function(simseR_result) {
  c(
    paste("- **R Version:** ", R.version.string),
    paste("- **simseR Package Version:** 1.0.0"),
    paste("- **Analysis Date:** ", Sys.Date()),
    "",
    "### Test Selection Logic",
    "",
    "1. Shapiro-Wilk test assesses normality for all groups",
    "2. If all groups are normal (p > α): Use parametric tests (t-tests)",
    "3. If any group is non-normal (p ≤ α): Use non-parametric tests (Wilcoxon)"
  )
}

# Placeholder functions for data tables (if include_data = TRUE)
generate_html_data_tables <- function(x, y) {
  content <- c(
    "    <h2>Raw Data</h2>",
    "    <h3>Group X Data</h3>",
    "    <div class='code'>",
    paste("   ", paste(round(x, 4), collapse = ", ")),
    "    </div>"
  )
  
  if (!is.null(y)) {
    content <- c(content,
      "    <h3>Group Y Data</h3>",
      "    <div class='code'>",
      paste("   ", paste(round(y, 4), collapse = ", ")),
      "    </div>"
    )
  }
  
  return(content)
}

generate_text_data_tables <- function(x, y) {
  content <- c(
    "Group X Data:",
    paste(round(x, 4), collapse = ", ")
  )
  
  if (!is.null(y)) {
    content <- c(content,
      "",
      "Group Y Data:",
      paste(round(y, 4), collapse = ", ")
    )
  }
  
  return(content)
}

generate_markdown_data_tables <- function(x, y) {
  content <- c(
    "### Group X Data",
    "",
    "```",
    paste(round(x, 4), collapse = ", "),
    "```"
  )
  
  if (!is.null(y)) {
    content <- c(content,
      "",
      "### Group Y Data",
      "",
      "```",
      paste(round(y, 4), collapse = ", "),
      "```"
    )
  }
  
  return(content)
}

