# simseR Package - Statistical Testing with Normality Assessment

## Overview

The **simseR** package provides automated statistical testing with intelligent test selection based on normality assessment. It performs Shapiro-Wilk normality tests and automatically chooses between parametric and non-parametric tests, ensuring appropriate statistical analysis for your data.

## Key Features

### ✅ **Automated Test Selection**
- **Normality Assessment**: Uses Shapiro-Wilk test to evaluate data distribution
- **Smart Test Choice**: Automatically selects parametric (t-tests) or non-parametric (Wilcoxon) tests
- **Multiple Test Types**: Supports one-sample, two-sample, and paired comparisons

### ✅ **Professional Visualizations**
- **Base R Graphics**: No external dependencies required
- **Multiple Plot Types**: 
  - `plot_normality()` - Normality assessment plots (histograms, Q-Q plots, boxplots)
  - `plot_results()` - Test results visualization
  - `plot_comprehensive()` - Combined analysis plots
  - `plot_diagnostic()` - Quick diagnostic plots
- **Publication Ready**: Clean, professional appearance suitable for reports

### ✅ **Comprehensive Reporting**
- **Multiple Formats**: HTML, text, markdown, and PDF reports
- **Enhanced PDF Generation**: Uses system utilities with automatic fallback to HTML
- **Professional Styling**: CSS-styled HTML reports with embedded visualizations
- **Detailed Content**: Executive summary, statistical results, interpretations, and recommendations

### ✅ **Robust Implementation**
- **Self-Contained**: Works with base R only (no external package dependencies)
- **Error Handling**: Comprehensive input validation and informative error messages
- **Cross-Platform**: Compatible with Windows, macOS, and Linux

## Quick Start

### Installation
```r
# Install from package file
install.packages("path/to/simseR_v1.1.0.tar.gz", repos = NULL, type = "source")

# Load the package
library(simseR)
```

### Basic Usage

#### One-Sample Test
```r
# Test if sample mean differs from hypothesized value
set.seed(123)
sample_data <- rnorm(30, mean = 5, sd = 2)
result <- simseR_test(sample_data, mu = 5)
print(result)
plot(result)
```

#### Two-Sample Test
```r
# Compare two independent groups
group1 <- rnorm(25, mean = 10, sd = 3)
group2 <- rnorm(25, mean = 12, sd = 3)
result <- simseR_test(group1, group2)
print(result)
plot_comprehensive(result, save_plot = TRUE)
```

#### Paired Test
```r
# Compare paired observations (e.g., before/after)
before <- rnorm(20, mean = 75, sd = 8)
after <- before + rnorm(20, mean = 3, sd = 2)
result <- simseR_test(before, after, paired = TRUE)
summary(result)
```

### Generate Reports
```r
# HTML report
simseR_report(result, "analysis.html", 
             title = "Statistical Analysis Report",
             author = "Research Team")

# PDF report with plots
simseR_report_pdf(result, "analysis.pdf", 
                 title = "Statistical Analysis Report",
                 include_plots = TRUE,
                 include_data = TRUE)
```

## Function Reference

### Core Functions
- `simseR_test()` - Main statistical testing function
- `extract_results()` - Extract results as a clean data frame

### Plotting Functions
- `plot_normality()` - Create normality assessment plots
- `plot_results()` - Create test results visualization
- `plot_comprehensive()` - Create comprehensive analysis plots
- `plot_diagnostic()` - Create quick diagnostic plots
- `plot.simseR()` - S3 method for plotting simseR objects

### Reporting Functions
- `simseR_report()` - Generate reports in HTML, text, or markdown format
- `simseR_report_pdf()` - Generate PDF reports with enhanced features

## Statistical Methods

### Test Selection Logic
1. **Normality Assessment**: Shapiro-Wilk test performed on all groups
2. **Decision Rule**: If all groups pass normality (p > α), use parametric tests; otherwise use non-parametric tests
3. **Parametric Tests**: t-tests (one-sample, two-sample, paired)
4. **Non-parametric Tests**: Wilcoxon tests (signed-rank, rank-sum)

### Supported Analyses
- **One-sample t-test** / Wilcoxon signed-rank test
- **Two-sample t-test** / Wilcoxon rank-sum test  
- **Paired t-test** / Paired Wilcoxon signed-rank test

## Dependencies

**Required (Base R only):**
- stats
- graphics
- grDevices
- utils
- tools

**Optional (for enhanced PDF generation):**
- System utilities: pandoc, LaTeX, or manus-md-to-pdf

## Use Cases

### Clinical Research
```r
# Compare treatment effectiveness
control_group <- c(2.1, 1.8, 2.3, 1.9, 2.0, 2.2, 1.7, 2.4, 1.8, 2.1)
treatment_group <- c(3.2, 2.9, 3.1, 3.4, 2.8, 3.3, 3.0, 3.2, 2.7, 3.1)

result <- simseR_test(control_group, treatment_group)
simseR_report_pdf(result, "clinical_study.pdf", 
                 title = "Treatment Efficacy Analysis")
```

### Quality Control
```r
# Test if production meets specifications
production_data <- c(98.2, 99.1, 97.8, 98.9, 99.3, 98.1, 99.0, 98.7, 99.2, 98.4)
target_mean <- 98.5

result <- simseR_test(production_data, mu = target_mean)
plot_diagnostic(result, save_plot = TRUE, filename = "qc_analysis.png")
```

### A/B Testing
```r
# Compare conversion rates
control_conversions <- rbinom(1000, 1, 0.12)  # 12% conversion rate
test_conversions <- rbinom(1000, 1, 0.15)     # 15% conversion rate

result <- simseR_test(control_conversions, test_conversions)
simseR_report(result, "ab_test_results.html", 
             title = "A/B Test Analysis",
             author = "Marketing Team")
```

## What's New in v1.1.0

### Fixed Issues
1. **Missing Helper Functions**: All reporting helper functions now properly included
2. **PDF Generation**: Multiple fallback methods implemented for robust PDF creation
3. **Plotting Dependencies**: Converted to base R graphics, eliminating external dependencies
4. **Error Handling**: Enhanced input validation and informative error messages

### Enhanced Features
1. **Professional Reports**: Improved styling and layout for all report formats
2. **Comprehensive Plotting**: Multiple plot types with automatic layout adjustment
3. **Cross-Platform Compatibility**: Tested on multiple operating systems
4. **Memory Efficiency**: Optimized for better performance with large datasets

## Support and Documentation

The simseR package provides comprehensive statistical analysis with professional-quality outputs, making it ideal for researchers, analysts, and data scientists who need reliable, automated statistical testing with appropriate test selection based on data characteristics.

For issues or questions, the package includes extensive error handling and informative messages to guide users through proper usage.

